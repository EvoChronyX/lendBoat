import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";


import.meta.env.VITE_STRIPE_PUBLIC_KEY="sk_test_51RVncARf6fe76T12jxTgwuKZHGwK2xX22wlola8QDb5UlyphG6Moca3AthrOgJHRutJEaUBT9jSxzJDglb6ajzDU00GvVVUTa8"

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const CheckoutForm = ({ bookingId, totalAmount }: { bookingId: string; totalAmount: number }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/booking/${bookingId}`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "Thank you for your booking!",
      });
    }

    setIsProcessing(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit" 
        disabled={!stripe || isProcessing}
        className="w-full bg-coral hover:bg-coral/90"
      >
        {isProcessing ? "Processing..." : `Pay $${totalAmount}`}
      </Button>
    </form>
  );
};

export default function Checkout() {
  const { bookingId } = useParams();
  const [clientSecret, setClientSecret] = useState("");

  const { data: booking, isLoading: bookingLoading } = useQuery({
    queryKey: [`/api/bookings/${bookingId}`],
    enabled: !!bookingId,
  });

  useEffect(() => {
    if (booking && booking.totalAmount) {
      // Create PaymentIntent as soon as we have booking data
      apiRequest("POST", "/api/create-payment-intent", { 
        amount: parseFloat(booking.totalAmount),
        bookingId: booking.id 
      })
        .then((res) => res.json())
        .then((data) => {
          setClientSecret(data.clientSecret);
        })
        .catch((error) => {
          console.error("Error creating payment intent:", error);
        });
    }
  }, [booking]);

  if (bookingLoading) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-20">
          <Card>
            <CardHeader>
              <Skeleton className="h-8 w-64" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-64 w-full" />
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  if (!booking) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Booking Not Found</h1>
          <p className="text-gray-600">Please check your booking details and try again.</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-20">
          <Card>
            <CardContent className="p-12 text-center">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
              <p>Preparing payment...</p>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      <section className="py-20 bg-light-gray">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-dark-teal mb-4">Complete Your Payment</h1>
            <p className="text-xl text-gray-600">Secure payment processing powered by Stripe</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Booking Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-dark-teal">Booking Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-semibold text-dark-teal mb-2">Booking Details</h3>
                  <p className="text-gray-600">Booking ID: #{booking.id}</p>
                  <p className="text-gray-600">Secret Key: {booking.secretKey}</p>
                </div>

                <div>
                  <h3 className="font-semibold text-dark-teal mb-2">Rental Period</h3>
                  <p className="text-gray-600">From: {formatDate(booking.startDate)}</p>
                  <p className="text-gray-600">To: {formatDate(booking.endDate)}</p>
                </div>

                <div className="border-t pt-4">
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-semibold text-dark-teal">Total Amount</span>
                    <span className="text-2xl font-bold text-coral">${booking.totalAmount}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Payment Form */}
            <Card>
              <CardHeader>
                <CardTitle className="text-dark-teal">Payment Information</CardTitle>
              </CardHeader>
              <CardContent>
                <Elements stripe={stripePromise} options={{ clientSecret }}>
                  <CheckoutForm bookingId={booking.secretKey} totalAmount={parseFloat(booking.totalAmount)} />
                </Elements>
              </CardContent>
            </Card>
          </div>

          {/* Security Info */}
          <Card className="mt-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-center space-x-4 text-gray-600">
                <div className="flex items-center space-x-2">
                  <i className="fas fa-lock text-green-600"></i>
                  <span>Secure SSL Encryption</span>
                </div>
                <div className="flex items-center space-x-2">
                  <i className="fas fa-shield-alt text-green-600"></i>
                  <span>PCI DSS Compliant</span>
                </div>
                <div className="flex items-center space-x-2">
                  <i className="fas fa-credit-card text-green-600"></i>
                  <span>Powered by Stripe</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
}

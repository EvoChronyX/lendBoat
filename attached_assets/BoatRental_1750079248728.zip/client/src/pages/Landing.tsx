import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import FeaturedBoats from "@/components/FeaturedBoats";
import TestimonialsSection from "@/components/TestimonialsSection";
import OwnerRegistrationForm from "@/components/OwnerRegistrationForm";
import Footer from "@/components/Footer";

export default function Landing() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <HeroSection />
      <FeaturedBoats />
      
      {/* Advertisement Section */}
      <section className="py-20 bg-gradient-to-r from-dark-teal to-teal">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h2 className="text-4xl font-bold mb-6">Special Summer Offers</h2>
              <div className="space-y-6">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
                  <h3 className="text-xl font-semibold mb-2">Early Bird Discount</h3>
                  <p className="text-white/90 mb-4">Book 7 days in advance and save up to 25% on your rental</p>
                  <span className="bg-sandal text-white px-4 py-2 rounded-lg font-medium">Save 25%</span>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
                  <h3 className="text-xl font-semibold mb-2">Weekend Getaway Package</h3>
                  <p className="text-white/90 mb-4">2-day weekend rentals with complimentary fuel and equipment</p>
                  <span className="bg-coral text-white px-4 py-2 rounded-lg font-medium">Free Extras</span>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
                  <h3 className="text-xl font-semibold mb-2">Group Booking Special</h3>
                  <p className="text-white/90 mb-4">Rent 3 or more boats and get the lowest priced one free</p>
                  <span className="bg-yellow-500 text-white px-4 py-2 rounded-lg font-medium">1 Free Boat</span>
                </div>
              </div>
            </div>
            <div className="hidden lg:block">
              <img 
                src="https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
                alt="Friends enjoying sunset party on yacht" 
                className="rounded-2xl shadow-2xl w-full h-auto" 
              />
            </div>
          </div>
        </div>
      </section>

      <TestimonialsSection />

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-dark-teal mb-6">About AquaRent</h2>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                Founded in 2020, AquaRent has become the premier destination for boat and yacht rentals. We connect water enthusiasts with premium vessels for unforgettable maritime experiences.
              </p>
              <div className="grid grid-cols-2 gap-6 mb-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-teal mb-2">500+</div>
                  <div className="text-gray-600">Premium Boats</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-teal mb-2">25,000+</div>
                  <div className="text-gray-600">Happy Customers</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-teal mb-2">15</div>
                  <div className="text-gray-600">Marina Locations</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-teal mb-2">4+</div>
                  <div className="text-gray-600">Years Experience</div>
                </div>
              </div>
              <p className="text-gray-700 leading-relaxed">
                Our mission is to make premium boating accessible to everyone, whether you're planning a romantic sunset cruise, an adventurous fishing trip, or a luxury yacht party.
              </p>
            </div>
            <div>
              <img 
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
                alt="Professional marina team on dock" 
                className="rounded-2xl shadow-lg w-full h-auto" 
              />
            </div>
          </div>
        </div>
      </section>

      <OwnerRegistrationForm />

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-dark-teal mb-4">Get In Touch</h2>
            <p className="text-xl text-gray-600">Have questions? We're here to help you find the perfect boat</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div>
              <h3 className="text-2xl font-bold text-dark-teal mb-6">Contact Information</h3>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-teal/10 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                    <i className="fas fa-map-marker-alt text-teal text-lg"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-dark-teal mb-1">Address</h4>
                    <p className="text-gray-600">123 Marina Boulevard<br />Miami Beach, FL 33139</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-teal/10 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                    <i className="fas fa-phone text-teal text-lg"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-dark-teal mb-1">Phone</h4>
                    <p className="text-gray-600">+1 (305) 555-0123</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-teal/10 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                    <i className="fas fa-envelope text-teal text-lg"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-dark-teal mb-1">Email</h4>
                    <p className="text-gray-600">hello@aquarent.com</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-teal/10 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                    <i className="fas fa-clock text-teal text-lg"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-dark-teal mb-1">Hours</h4>
                    <p className="text-gray-600">Mon - Fri: 8:00 AM - 8:00 PM<br />Sat - Sun: 9:00 AM - 6:00 PM</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div>
              <h3 className="text-2xl font-bold text-dark-teal mb-6">Send us a Message</h3>
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                    <input 
                      type="text" 
                      required 
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-teal focus:border-transparent" 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                    <input 
                      type="text" 
                      required 
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-teal focus:border-transparent" 
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input 
                    type="email" 
                    required 
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-teal focus:border-transparent" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Subject</label>
                  <select 
                    required 
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-teal focus:border-transparent"
                  >
                    <option value="">Select a subject</option>
                    <option value="booking">Booking Inquiry</option>
                    <option value="support">Technical Support</option>
                    <option value="owner">Owner Registration</option>
                    <option value="general">General Question</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                  <textarea 
                    rows={5} 
                    required 
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-teal focus:border-transparent"
                  ></textarea>
                </div>
                <button 
                  type="submit" 
                  className="w-full bg-teal text-white py-3 rounded-xl font-semibold hover:bg-dark-teal transition-colors"
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

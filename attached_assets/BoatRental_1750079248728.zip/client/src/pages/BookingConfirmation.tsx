import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle, Calendar, MapPin, User, Anchor } from "lucide-react";

export default function BookingConfirmation() {
  const { secretKey } = useParams();

  const { data: booking, isLoading, error } = useQuery({
    queryKey: [`/api/bookings/${secretKey}`],
    enabled: !!secretKey,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-20">
          <Card>
            <CardHeader>
              <Skeleton className="h-8 w-64" />
              <Skeleton className="h-4 w-96" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !booking) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Booking Not Found</h1>
          <p className="text-gray-600">Please check your secret key and try again.</p>
        </div>
        <Footer />
      </div>
    );
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed": return "bg-green-100 text-green-800";
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      <section className="py-20 bg-light-gray">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </div>
            <h1 className="text-4xl font-bold text-dark-teal mb-4">Booking Confirmation</h1>
            <p className="text-xl text-gray-600">Your booking has been successfully created!</p>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-2xl text-dark-teal mb-2">Booking Details</CardTitle>
                  <p className="text-gray-600">Secret Key: <span className="font-mono font-bold text-lg">{booking.secretKey}</span></p>
                </div>
                <Badge className={getStatusColor(booking.status)}>
                  {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="flex items-start space-x-3">
                    <Anchor className="w-5 h-5 text-teal mt-1" />
                    <div>
                      <h3 className="font-semibold text-dark-teal">Boat Information</h3>
                      <p className="text-gray-600">Boat ID: {booking.boatId}</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Calendar className="w-5 h-5 text-teal mt-1" />
                    <div>
                      <h3 className="font-semibold text-dark-teal">Rental Period</h3>
                      <p className="text-gray-600">From: {formatDate(booking.startDate)}</p>
                      <p className="text-gray-600">To: {formatDate(booking.endDate)}</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <User className="w-5 h-5 text-teal mt-1" />
                    <div>
                      <h3 className="font-semibold text-dark-teal">Customer</h3>
                      <p className="text-gray-600">User ID: {booking.userId}</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="bg-light-gray p-6 rounded-xl">
                    <h3 className="font-semibold text-dark-teal mb-4">Payment Summary</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Amount:</span>
                        <span className="font-bold text-2xl text-coral">${booking.totalAmount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Payment Status:</span>
                        <Badge className={getStatusColor(booking.paymentStatus || 'pending')}>
                          {booking.paymentStatus?.charAt(0).toUpperCase() + booking.paymentStatus?.slice(1) || 'Pending'}
                        </Badge>
                      </div>
                    </div>
                  </div>

                  {booking.paymentStatus === 'pending' && (
                    <Button 
                      className="w-full bg-coral hover:bg-coral/90" 
                      onClick={() => window.location.href = `/checkout/${booking.id}`}
                    >
                      Complete Payment
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-dark-teal">Important Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 text-gray-700">
                <div>
                  <h4 className="font-semibold mb-2">✓ Confirmation Sent</h4>
                  <p>A confirmation email has been sent to your registered email address with all booking details.</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">📞 Customer Support</h4>
                  <p>If you have any questions, please contact us at +1 (305) 555-0123 or hello@aquarent.com</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">🔑 Your Secret Key</h4>
                  <p>Keep your secret key <span className="font-mono bg-gray-100 px-2 py-1 rounded">{booking.secretKey}</span> safe. You'll need it to access your booking details.</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">📋 What's Next?</h4>
                  <p>Please arrive at the marina 30 minutes before your scheduled time. Bring a valid ID and your booking confirmation.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
}

import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import AnalyticsChart from "@/components/AnalyticsChart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Users, Sailboat, DollarSign, TrendingUp, Check, X, Eye } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function AdminDashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const [rejectionReason, setRejectionReason] = useState("");
  const [selectedOwner, setSelectedOwner] = useState<any>(null);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: owners, isLoading: ownersLoading } = useQuery({
    queryKey: ["/api/admin/owners"],
    retry: false,
    enabled: isAuthenticated && user?.role === 'admin',
  });

  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ["/api/admin/analytics"],
    retry: false,
    enabled: isAuthenticated && user?.role === 'admin',
  });

  const { data: testimonials, isLoading: testimonialsLoading } = useQuery({
    queryKey: ["/api/admin/testimonials"],
    retry: false,
    enabled: isAuthenticated && user?.role === 'admin',
  });

  const updateOwnerMutation = useMutation({
    mutationFn: async ({ id, status, rejectionReason }: { id: number; status: string; rejectionReason?: string }) => {
      await apiRequest("PUT", `/api/admin/owners/${id}/status`, { status, rejectionReason });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/owners"] });
      toast({
        title: "Success",
        description: "Owner status updated successfully",
      });
      setSelectedOwner(null);
      setRejectionReason("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update owner status",
        variant: "destructive",
      });
    },
  });

  const updateTestimonialMutation = useMutation({
    mutationFn: async ({ id, isApproved }: { id: number; isApproved: boolean }) => {
      await apiRequest("PUT", `/api/admin/testimonials/${id}/approve`, { isApproved });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/testimonials"] });
      toast({
        title: "Success",
        description: "Testimonial status updated successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update testimonial status",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 py-20">
          <Skeleton className="h-8 w-64 mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-4 w-16 mb-2" />
                  <Skeleton className="h-8 w-12" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Access Denied</h1>
          <p className="text-gray-600">You don't have permission to access the admin dashboard.</p>
        </div>
        <Footer />
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved": return "bg-green-100 text-green-800";
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "rejected": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const handleApproveOwner = (ownerId: number) => {
    updateOwnerMutation.mutate({ id: ownerId, status: "approved" });
  };

  const handleRejectOwner = (ownerId: number) => {
    if (!rejectionReason.trim()) {
      toast({
        title: "Error",
        description: "Please provide a rejection reason",
        variant: "destructive",
      });
      return;
    }
    updateOwnerMutation.mutate({ 
      id: ownerId, 
      status: "rejected", 
      rejectionReason: rejectionReason.trim() 
    });
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      <section className="py-20 bg-light-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-dark-teal">Admin Dashboard</h1>
            <p className="text-xl text-gray-600 mt-2">Manage users, owners, boats, and analytics</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Users</p>
                    <p className="text-2xl font-bold text-dark-teal">1,234</p>
                  </div>
                  <Users className="h-8 w-8 text-teal" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Boats</p>
                    <p className="text-2xl font-bold text-dark-teal">89</p>
                  </div>
                  <Sailboat className="h-8 w-8 text-teal" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                    <p className="text-2xl font-bold text-dark-teal">
                      ${analyticsLoading ? '...' : analytics?.bookingStats?.totalRevenue?.toLocaleString() || '0'}
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-teal" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Bookings</p>
                    <p className="text-2xl font-bold text-dark-teal">
                      {analyticsLoading ? '...' : analytics?.bookingStats?.totalBookings || '0'}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-teal" />
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="owners" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="owners">Owner Approvals</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="testimonials">Testimonials</TabsTrigger>
              <TabsTrigger value="users">Users</TabsTrigger>
            </TabsList>

            <TabsContent value="owners" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Owner Registration Requests</CardTitle>
                </CardHeader>
                <CardContent>
                  {ownersLoading ? (
                    <div className="space-y-4">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className="flex items-center justify-between p-4 border rounded">
                          <div className="space-y-2">
                            <Skeleton className="h-4 w-32" />
                            <Skeleton className="h-3 w-48" />
                          </div>
                          <Skeleton className="h-8 w-20" />
                        </div>
                      ))}
                    </div>
                  ) : owners && owners.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Phone</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Created</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {owners.map((owner: any) => (
                          <TableRow key={owner.id}>
                            <TableCell className="font-medium">
                              {owner.firstName} {owner.lastName}
                            </TableCell>
                            <TableCell>{owner.email}</TableCell>
                            <TableCell>{owner.phone}</TableCell>
                            <TableCell>
                              <Badge className={getStatusColor(owner.status)}>
                                {owner.status.charAt(0).toUpperCase() + owner.status.slice(1)}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {new Date(owner.createdAt).toLocaleDateString()}
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                {owner.status === 'pending' && (
                                  <>
                                    <Button
                                      size="sm"
                                      className="bg-green-600 hover:bg-green-700"
                                      onClick={() => handleApproveOwner(owner.id)}
                                      disabled={updateOwnerMutation.isPending}
                                    >
                                      <Check className="h-4 w-4" />
                                    </Button>
                                    <Dialog>
                                      <DialogTrigger asChild>
                                        <Button
                                          size="sm"
                                          variant="destructive"
                                          onClick={() => setSelectedOwner(owner)}
                                        >
                                          <X className="h-4 w-4" />
                                        </Button>
                                      </DialogTrigger>
                                      <DialogContent>
                                        <DialogHeader>
                                          <DialogTitle>Reject Owner Application</DialogTitle>
                                        </DialogHeader>
                                        <div className="space-y-4">
                                          <p>
                                            Are you sure you want to reject the application from {selectedOwner?.firstName} {selectedOwner?.lastName}?
                                          </p>
                                          <Textarea
                                            placeholder="Please provide a reason for rejection..."
                                            value={rejectionReason}
                                            onChange={(e) => setRejectionReason(e.target.value)}
                                          />
                                          <div className="flex justify-end space-x-2">
                                            <Button
                                              variant="outline"
                                              onClick={() => {
                                                setSelectedOwner(null);
                                                setRejectionReason("");
                                              }}
                                            >
                                              Cancel
                                            </Button>
                                            <Button
                                              variant="destructive"
                                              onClick={() => selectedOwner && handleRejectOwner(selectedOwner.id)}
                                              disabled={updateOwnerMutation.isPending}
                                            >
                                              Reject
                                            </Button>
                                          </div>
                                        </div>
                                      </DialogContent>
                                    </Dialog>
                                  </>
                                )}
                                <Button size="sm" variant="outline">
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center py-8">
                      <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-700 mb-2">No pending applications</h3>
                      <p className="text-gray-600">All owner applications have been processed.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Booking Trends</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {analyticsLoading ? (
                      <Skeleton className="h-64 w-full" />
                    ) : (
                      <AnalyticsChart data={analytics?.bookingStats?.monthlyBookings || []} />
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Popular Boats</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {analyticsLoading ? (
                      <div className="space-y-4">
                        {[...Array(5)].map((_, i) => (
                          <div key={i} className="flex justify-between">
                            <Skeleton className="h-4 w-32" />
                            <Skeleton className="h-4 w-12" />
                          </div>
                        ))}
                      </div>
                    ) : analytics?.popularBoats && analytics.popularBoats.length > 0 ? (
                      <div className="space-y-4">
                        {analytics.popularBoats.slice(0, 5).map((item: any, index: number) => (
                          <div key={item.boat.id} className="flex justify-between items-center">
                            <div>
                              <p className="font-medium">{item.boat.name}</p>
                              <p className="text-sm text-gray-600">{item.boat.type}</p>
                            </div>
                            <div className="text-right">
                              <p className="font-bold text-coral">{item.bookingCount}</p>
                              <p className="text-sm text-gray-600">bookings</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600">No booking data available yet.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="testimonials" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Testimonial Moderation</CardTitle>
                </CardHeader>
                <CardContent>
                  {testimonialsLoading ? (
                    <div className="space-y-4">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className="p-4 border rounded">
                          <Skeleton className="h-4 w-full mb-2" />
                          <Skeleton className="h-4 w-3/4 mb-2" />
                          <Skeleton className="h-4 w-32" />
                        </div>
                      ))}
                    </div>
                  ) : testimonials && testimonials.length > 0 ? (
                    <div className="space-y-4">
                      {testimonials.map((testimonial: any) => (
                        <div key={testimonial.id} className="p-4 border rounded-lg">
                          <div className="flex justify-between items-start mb-2">
                            <div className="flex items-center space-x-2">
                              <div className="flex text-yellow-400">
                                {[...Array(testimonial.rating)].map((_, i) => (
                                  <span key={i}>★</span>
                                ))}
                              </div>
                              <Badge className={testimonial.isApproved ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}>
                                {testimonial.isApproved ? "Approved" : "Pending"}
                              </Badge>
                            </div>
                            {!testimonial.isApproved && (
                              <div className="flex space-x-2">
                                <Button
                                  size="sm"
                                  className="bg-green-600 hover:bg-green-700"
                                  onClick={() => updateTestimonialMutation.mutate({ id: testimonial.id, isApproved: true })}
                                >
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => updateTestimonialMutation.mutate({ id: testimonial.id, isApproved: false })}
                                >
                                  Reject
                                </Button>
                              </div>
                            )}
                          </div>
                          <p className="text-gray-700 mb-2">{testimonial.content}</p>
                          <p className="text-sm text-gray-500">
                            User ID: {testimonial.userId} • {new Date(testimonial.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <h3 className="text-lg font-semibold text-gray-700 mb-2">No testimonials</h3>
                      <p className="text-gray-600">Customer testimonials will appear here for moderation.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="users" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>User Management</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-700 mb-2">User Management</h3>
                    <p className="text-gray-600">User management features will be available here.</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <Footer />
    </div>
  );
}

import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Sailboat, Calendar, DollarSign, Star } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function OwnerDashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: ownerProfile, isLoading: ownerLoading } = useQuery({
    queryKey: ["/api/owners/me"],
    retry: false,
    enabled: isAuthenticated,
  });

  const { data: boats, isLoading: boatsLoading } = useQuery({
    queryKey: ["/api/boats/owner"],
    retry: false,
    enabled: isAuthenticated && ownerProfile?.status === 'approved',
  });

  if (isLoading || ownerLoading) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 py-20">
          <Skeleton className="h-8 w-64 mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {[...Array(3)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-4 w-16 mb-2" />
                  <Skeleton className="h-8 w-12" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!ownerProfile) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold text-dark-teal mb-4">Owner Registration Required</h1>
          <p className="text-gray-600 mb-8">You need to register as a boat owner to access this dashboard.</p>
          <Button onClick={() => window.location.href = "/#owner-registration"} className="bg-teal hover:bg-dark-teal">
            Register as Owner
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved": return "bg-green-100 text-green-800";
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "rejected": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      <section className="py-20 bg-light-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-4xl font-bold text-dark-teal">Owner Dashboard</h1>
              <p className="text-xl text-gray-600 mt-2">Welcome back, {ownerProfile.firstName}!</p>
            </div>
            <Badge className={getStatusColor(ownerProfile.status)}>
              {ownerProfile.status.charAt(0).toUpperCase() + ownerProfile.status.slice(1)}
            </Badge>
          </div>

          {ownerProfile.status === 'pending' && (
            <Card className="mb-8 border-yellow-200 bg-yellow-50">
              <CardContent className="p-6">
                <h3 className="font-semibold text-yellow-800 mb-2">Registration Under Review</h3>
                <p className="text-yellow-700">
                  Your owner registration is currently being reviewed by our admin team. 
                  You'll receive an email notification once your application is processed.
                </p>
              </CardContent>
            </Card>
          )}

          {ownerProfile.status === 'rejected' && (
            <Card className="mb-8 border-red-200 bg-red-50">
              <CardContent className="p-6">
                <h3 className="font-semibold text-red-800 mb-2">Registration Rejected</h3>
                <p className="text-red-700 mb-2">
                  Unfortunately, your owner registration was not approved.
                </p>
                {ownerProfile.rejectionReason && (
                  <p className="text-red-700">
                    <strong>Reason:</strong> {ownerProfile.rejectionReason}
                  </p>
                )}
              </CardContent>
            </Card>
          )}

          {ownerProfile.status === 'approved' && (
            <>
              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Total Boats</p>
                        <p className="text-2xl font-bold text-dark-teal">{boats?.length || 0}</p>
                      </div>
                      <Sailboat className="h-8 w-8 text-teal" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Active Bookings</p>
                        <p className="text-2xl font-bold text-dark-teal">0</p>
                      </div>
                      <Calendar className="h-8 w-8 text-teal" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                        <p className="text-2xl font-bold text-dark-teal">$0</p>
                      </div>
                      <DollarSign className="h-8 w-8 text-teal" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Avg Rating</p>
                        <p className="text-2xl font-bold text-dark-teal">0.0</p>
                      </div>
                      <Star className="h-8 w-8 text-teal" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Tabs defaultValue="boats" className="space-y-6">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="boats">My Boats</TabsTrigger>
                  <TabsTrigger value="bookings">Bookings</TabsTrigger>
                  <TabsTrigger value="analytics">Analytics</TabsTrigger>
                </TabsList>

                <TabsContent value="boats" className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-dark-teal">My Boats</h2>
                    <Button className="bg-teal hover:bg-dark-teal">
                      <Plus className="mr-2 h-4 w-4" />
                      Add New Sailboat
                    </Button>
                  </div>

                  {boatsLoading ? (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {[...Array(3)].map((_, i) => (
                        <Card key={i}>
                          <Skeleton className="h-48 w-full" />
                          <CardContent className="p-6">
                            <Skeleton className="h-4 w-20 mb-2" />
                            <Skeleton className="h-6 w-32 mb-4" />
                            <Skeleton className="h-4 w-full" />
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : boats && boats.length > 0 ? (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {boats.map((boat: any) => (
                        <Card key={boat.id}>
                          <div className="h-48 bg-gray-200 rounded-t-lg"></div>
                          <CardContent className="p-6">
                            <div className="flex items-center justify-between mb-2">
                              <Badge className="bg-teal/10 text-teal">
                                {boat.type.charAt(0).toUpperCase() + boat.type.slice(1)}
                              </Badge>
                              <div className="flex items-center text-yellow-400">
                                <Star className="h-4 w-4 fill-current" />
                                <span className="ml-1 text-sm text-gray-600">{boat.rating || '0.0'}</span>
                              </div>
                            </div>
                            <h3 className="text-xl font-bold text-dark-teal mb-2">{boat.name}</h3>
                            <p className="text-gray-600 text-sm mb-4 line-clamp-2">{boat.description}</p>
                            <div className="flex items-center justify-between">
                              <div>
                                <span className="text-2xl font-bold text-coral">${boat.dailyRate}</span>
                                <span className="text-gray-500 text-sm">/day</span>
                              </div>
                              <Button variant="outline" size="sm">
                                Edit
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <Card>
                      <CardContent className="p-12 text-center">
                        <Sailboat className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-gray-700 mb-2">No boats listed yet</h3>
                        <p className="text-gray-600 mb-6">Start earning by listing your first boat!</p>
                        <Button className="bg-teal hover:bg-dark-teal">
                          <Plus className="mr-2 h-4 w-4" />
                          Add Your First Sailboat
                        </Button>
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>

                <TabsContent value="bookings" className="space-y-6">
                  <h2 className="text-2xl font-bold text-dark-teal">Recent Bookings</h2>
                  <Card>
                    <CardContent className="p-12 text-center">
                      <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-700 mb-2">No bookings yet</h3>
                      <p className="text-gray-600">Your bookings will appear here once customers start renting your boats.</p>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="analytics" className="space-y-6">
                  <h2 className="text-2xl font-bold text-dark-teal">Analytics & Performance</h2>
                  <Card>
                    <CardContent className="p-12 text-center">
                      <DollarSign className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-700 mb-2">Analytics Coming Soon</h3>
                      <p className="text-gray-600">Detailed analytics and performance metrics will be available once you have active bookings.</p>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}

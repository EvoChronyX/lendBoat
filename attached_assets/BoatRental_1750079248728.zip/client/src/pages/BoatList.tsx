import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/Navigation";
import BoatCard from "@/components/BoatCard";
import Footer from "@/components/Footer";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Search } from "lucide-react";

export default function BoatList() {
  const [filters, setFilters] = useState({
    location: "",
    type: "",
    date: "",
  });

  const { data: boats, isLoading, error } = useQuery({
    queryKey: ["/api/boats", filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters.type && filters.type !== "All Types") params.set("type", filters.type);
      if (filters.location) params.set("location", filters.location);
      
      const response = await fetch(`/api/boats?${params}`);
      if (!response.ok) throw new Error("Failed to fetch boats");
      return response.json();
    },
  });

  const handleSearch = () => {
    // Trigger refetch with current filters
    window.location.reload();
  };

  if (error) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Error Loading Boats</h1>
          <p className="text-gray-600">Please try again later.</p>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold text-dark-teal mb-4">All Boats & Yachts</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">Find your perfect vessel for the ultimate maritime experience</p>
          </div>

          {/* Search and Filter Bar */}
          <Card className="mb-12">
            <CardContent className="p-6">
              <div className="grid md:grid-cols-4 gap-4">
                <div className="md:col-span-1">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                  <Input
                    type="text"
                    placeholder="Where to?"
                    value={filters.location}
                    onChange={(e) => setFilters(prev => ({ ...prev, location: e.target.value }))}
                  />
                </div>
                <div className="md:col-span-1">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Boat Type</label>
                  <Select value={filters.type} onValueChange={(value) => setFilters(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="All Types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="All Types">All Types</SelectItem>
                      <SelectItem value="yacht">Yacht</SelectItem>
                      <SelectItem value="sailboat">Sailboat</SelectItem>
                      <SelectItem value="speedboat">Speedboat</SelectItem>
                      <SelectItem value="catamaran">Catamaran</SelectItem>
                      <SelectItem value="fishing">Fishing Boat</SelectItem>
                      <SelectItem value="pontoon">Pontoon</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="md:col-span-1">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Date</label>
                  <Input
                    type="date"
                    value={filters.date}
                    onChange={(e) => setFilters(prev => ({ ...prev, date: e.target.value }))}
                  />
                </div>
                <div className="md:col-span-1 flex items-end">
                  <Button onClick={handleSearch} className="w-full bg-teal hover:bg-dark-teal">
                    <Search className="mr-2 h-4 w-4" />
                    Search
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Boats Grid */}
          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(6)].map((_, i) => (
                <Card key={i}>
                  <Skeleton className="h-48 w-full" />
                  <CardContent className="p-6">
                    <Skeleton className="h-4 w-20 mb-2" />
                    <Skeleton className="h-6 w-32 mb-2" />
                    <Skeleton className="h-4 w-full mb-4" />
                    <div className="flex justify-between">
                      <Skeleton className="h-6 w-16" />
                      <Skeleton className="h-8 w-20" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : boats && boats.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {boats.map((boat: any) => (
                <BoatCard key={boat.id} boat={boat} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <h3 className="text-xl font-semibold text-gray-700 mb-4">No boats found</h3>
              <p className="text-gray-600">Try adjusting your search filters to find more options.</p>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}

import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Star } from "lucide-react";

export default function TestimonialsSection() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const { data: testimonials, isLoading } = useQuery({
    queryKey: ["/api/testimonials"],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  // Default testimonials in case API is not available
  const defaultTestimonials = [
    {
      id: 1,
      content: "The Ocean Majesty exceeded all our expectations! The yacht was immaculate and the booking process was seamless. Our family vacation was absolutely perfect thanks to AquaRent.",
      rating: 5,
      user: {
        firstName: "Sarah",
        lastName: "Johnson",
        profileImageUrl: "https://pixabay.com/get/g3658403bdafe81b43740f6df1fdc01533a1c6ffe6a5755b50210c6c4004c43aee1818ef7aac007f6089b9dfa3e2882b20ce1965d76e30835cf5ebcb5d5706bbc_1280.jpg"
      },
      location: "Miami, FL"
    },
    {
      id: 2,
      content: "Incredible service! The Thunder Wave speedboat was exactly what we needed for our water sports adventure. Fast booking, fair pricing, and amazing customer support.",
      rating: 5,
      user: {
        firstName: "Michael",
        lastName: "Chen",
        profileImageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64"
      },
      location: "San Diego, CA"
    },
    {
      id: 3,
      content: "The Wind Dancer sailboat gave us the most peaceful and romantic sunset sail. AquaRent made our anniversary unforgettable. Highly recommend!",
      rating: 5,
      user: {
        firstName: "Emma",
        lastName: "Rodriguez",
        profileImageUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64"
      },
      location: "Key West, FL"
    }
  ];

  const displayTestimonials = testimonials && testimonials.length > 0 ? testimonials : defaultTestimonials;
  const totalSlides = displayTestimonials.length;

  const goToSlide = (slideIndex: number) => {
    setCurrentSlide(slideIndex);
  };

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % totalSlides);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + totalSlides) % totalSlides);
  };

  // Auto-play functionality
  useEffect(() => {
    const interval = setInterval(nextSlide, 5000);
    return () => clearInterval(interval);
  }, [totalSlides]);

  if (isLoading) {
    return (
      <section className="py-20 bg-light-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-dark-teal mb-4">What Our Customers Say</h2>
            <p className="text-xl text-gray-600">Real experiences from our satisfied customers</p>
          </div>
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-8">
              <div className="animate-pulse space-y-4">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-full"></div>
                <div className="h-4 bg-gray-200 rounded w-2/3"></div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-light-gray">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-dark-teal mb-4">What Our Customers Say</h2>
          <p className="text-xl text-gray-600">Real experiences from our satisfied customers</p>
        </div>

        {/* Testimonials Slider */}
        <div className="relative overflow-hidden">
          <div 
            className="flex transition-transform duration-500 ease-in-out"
            style={{ transform: `translateX(-${currentSlide * 100}%)` }}
          >
            {displayTestimonials.map((testimonial: any) => (
              <div key={testimonial.id} className="w-full flex-shrink-0 px-4">
                <Card className="bg-white rounded-2xl shadow-lg mx-auto max-w-2xl">
                  <CardContent className="p-8">
                    <div className="flex items-center mb-4">
                      <div className="flex text-yellow-400 mr-4">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="h-5 w-5 fill-current" />
                        ))}
                      </div>
                      <span className="text-gray-600 text-sm">{testimonial.rating}.0</span>
                    </div>
                    
                    <p className="text-gray-700 text-lg mb-6 leading-relaxed">
                      "{testimonial.content}"
                    </p>
                    
                    <div className="flex items-center">
                      <img 
                        src={testimonial.user?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64"}
                        alt="Customer"
                        className="w-12 h-12 rounded-full object-cover mr-4"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64";
                        }}
                      />
                      <div>
                        <h4 className="font-semibold text-dark-teal">
                          {testimonial.user ? 
                            `${testimonial.user.firstName} ${testimonial.user.lastName}` : 
                            testimonial.user?.firstName || "Customer"
                          }
                        </h4>
                        <p className="text-gray-600 text-sm">
                          {testimonial.location || "Verified Customer"}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>

          {/* Navigation Buttons */}
          <Button
            variant="outline"
            size="icon"
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white rounded-full shadow-lg hover:shadow-xl z-10"
            onClick={prevSlide}
          >
            <ChevronLeft className="h-4 w-4 text-teal" />
          </Button>
          
          <Button
            variant="outline"
            size="icon"
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white rounded-full shadow-lg hover:shadow-xl z-10"
            onClick={nextSlide}
          >
            <ChevronRight className="h-4 w-4 text-teal" />
          </Button>

          {/* Slide Indicators */}
          <div className="flex justify-center mt-8 space-x-2">
            {displayTestimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentSlide ? 'bg-teal' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

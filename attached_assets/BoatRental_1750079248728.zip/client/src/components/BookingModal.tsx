import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { CalendarIcon, Star, MapPin, Users, Ruler } from "lucide-react";
import { format, differenceInDays, addDays } from "date-fns";
import { cn } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";

interface Boat {
  id: number;
  name: string;
  type: string;
  description: string;
  length: number;
  capacity: number;
  dailyRate: string;
  location: string;
  images: string[];
  rating: string;
}

interface BookingModalProps {
  boat: Boat;
  isOpen: boolean;
  onClose: () => void;
}

export default function BookingModal({ boat, isOpen, onClose }: BookingModalProps) {
  const { toast } = useToast();
  const { isAuthenticated, user } = useAuth();
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [specialRequests, setSpecialRequests] = useState("");

  const bookingMutation = useMutation({
    mutationFn: async (bookingData: any) => {
      if (!isAuthenticated) {
        window.location.href = "/api/login";
        return;
      }
      const response = await apiRequest("POST", "/api/bookings", bookingData);
      return response.json();
    },
    onSuccess: (booking) => {
      toast({
        title: "Booking Created Successfully!",
        description: `Your booking has been created with secret key: ${booking.secretKey}`,
      });
      onClose();
      // Redirect to booking confirmation
      window.location.href = `/booking/${booking.secretKey}`;
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Authentication Required",
          description: "Please log in to make a booking.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 2000);
        return;
      }
      toast({
        title: "Booking Failed",
        description: "There was an error creating your booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const calculateTotal = () => {
    if (!startDate || !endDate) return 0;
    const days = differenceInDays(endDate, startDate) + 1;
    return days * parseFloat(boat.dailyRate);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to make a booking.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 2000);
      return;
    }

    if (!startDate || !endDate) {
      toast({
        title: "Dates Required",
        description: "Please select both start and end dates.",
        variant: "destructive",
      });
      return;
    }

    if (startDate < new Date()) {
      toast({
        title: "Invalid Date",
        description: "Start date cannot be in the past.",
        variant: "destructive",
      });
      return;
    }

    if (endDate <= startDate) {
      toast({
        title: "Invalid Date Range",
        description: "End date must be after start date.",
        variant: "destructive",
      });
      return;
    }

    const bookingData = {
      boatId: boat.id,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      totalAmount: calculateTotal(),
      specialRequests,
    };

    bookingMutation.mutate(bookingData);
  };

  const getDefaultImage = (type: string) => {
    switch (type.toLowerCase()) {
      case "yacht":
        return "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250";
      case "sailboat":
        return "https://images.unsplash.com/photo-1567899378494-47b22a2ae96a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250";
      case "speedboat":
        return "https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250";
      case "catamaran":
        return "https://images.unsplash.com/photo-1551244072-5d12893278ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250";
      case "fishing":
        return "https://pixabay.com/get/g351792dbb3affc658363576e204898b4883770448464c8ed346b5fac912a44fde2288c15f235021eb938783f0a1c7a39f642cc72ad7b629b22da5b189314f3d5_1280.jpg";
      case "pontoon":
        return "https://pixabay.com/get/gb449283ba3d3cef73df523a11e54b7bc771865c015bd394ed583407562764cdc177cf57c262cfb4b97eb020f5a5dcde1f3824c5428f3d9ae69da1e1033add851_1280.jpg";
      default:
        return "https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250";
    }
  };

  const displayImage = boat.images && boat.images.length > 0 ? boat.images[0] : getDefaultImage(boat.type);
  const rating = parseFloat(boat.rating || "0");
  const days = startDate && endDate ? differenceInDays(endDate, startDate) + 1 : 0;
  const total = calculateTotal();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-dark-teal">Book {boat.name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Boat Details */}
          <div className="flex flex-col md:flex-row gap-6">
            <img 
              src={displayImage}
              alt={boat.name}
              className="w-full md:w-48 h-32 object-cover rounded-lg"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = getDefaultImage(boat.type);
              }}
            />
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Badge className="bg-teal/10 text-teal">
                  {boat.type.charAt(0).toUpperCase() + boat.type.slice(1)}
                </Badge>
                <div className="flex items-center text-yellow-400">
                  <Star className="h-4 w-4 fill-current" />
                  <span className="ml-1 text-sm text-gray-600">
                    {rating > 0 ? rating.toFixed(1) : "New"}
                  </span>
                </div>
              </div>
              <h3 className="text-xl font-bold text-dark-teal mb-2">{boat.name}</h3>
              <div className="flex items-center text-sm text-gray-600 space-x-4 mb-2">
                <div className="flex items-center">
                  <Ruler className="h-4 w-4 mr-1" />
                  <span>{boat.length}ft</span>
                </div>
                <div className="flex items-center">
                  <Users className="h-4 w-4 mr-1" />
                  <span>Up to {boat.capacity}</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span>{boat.location}</span>
                </div>
              </div>
              <p className="text-gray-600 text-sm line-clamp-2">{boat.description}</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Date Selection */}
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !startDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {startDate ? format(startDate, "PPP") : "Select start date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={startDate}
                      onSelect={setStartDate}
                      disabled={(date) => date < new Date()}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !endDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {endDate ? format(endDate, "PPP") : "Select end date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={endDate}
                      onSelect={setEndDate}
                      disabled={(date) => date < (startDate || new Date())}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            {/* Special Requests */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Special Requests (Optional)</label>
              <Textarea
                value={specialRequests}
                onChange={(e) => setSpecialRequests(e.target.value)}
                placeholder="Any special requests or requirements..."
                rows={3}
              />
            </div>

            {/* Pricing Summary */}
            {startDate && endDate && (
              <div className="bg-light-gray p-4 rounded-lg">
                <h4 className="font-semibold text-dark-teal mb-3">Booking Summary</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Daily Rate:</span>
                    <span>${parseFloat(boat.dailyRate).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Number of Days:</span>
                    <span>{days}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Dates:</span>
                    <span>{format(startDate, "MMM dd")} - {format(endDate, "MMM dd")}</span>
                  </div>
                  <div className="border-t pt-2 flex justify-between font-semibold text-lg">
                    <span>Total:</span>
                    <span className="text-coral">${total.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={!startDate || !endDate || bookingMutation.isPending}
                className="flex-1 bg-coral hover:bg-coral/90"
              >
                {bookingMutation.isPending ? "Creating Booking..." : "Book Now"}
              </Button>
            </div>

            {!isAuthenticated && (
              <p className="text-sm text-gray-600 text-center">
                You'll be redirected to sign in before completing your booking.
              </p>
            )}
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}

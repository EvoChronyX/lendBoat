import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";
import BookingModal from "./BookingModal";

interface Boat {
  id: number;
  name: string;
  type: string;
  description: string;
  length: number;
  capacity: number;
  dailyRate: string;
  location: string;
  images: string[];
  rating: string;
  isActive: boolean;
}

interface BoatCardProps {
  boat: Boat;
}

export default function BoatCard({ boat }: BoatCardProps) {
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);

  const getTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case "yacht":
        return "bg-teal/10 text-teal";
      case "sailboat":
        return "bg-sandal/10 text-sandal";
      case "speedboat":
        return "bg-coral/10 text-coral";
      case "catamaran":
        return "bg-teal/10 text-teal";
      case "fishing":
        return "bg-sandal/10 text-sandal";
      case "pontoon":
        return "bg-teal/10 text-teal";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getDefaultImage = (type: string) => {
    switch (type.toLowerCase()) {
      case "yacht":
        return "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250";
      case "sailboat":
        return "https://images.unsplash.com/photo-1567899378494-47b22a2ae96a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250";
      case "speedboat":
        return "https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250";
      case "catamaran":
        return "https://images.unsplash.com/photo-1551244072-5d12893278ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250";
      case "fishing":
        return "https://pixabay.com/get/g351792dbb3affc658363576e204898b4883770448464c8ed346b5fac912a44fde2288c15f235021eb938783f0a1c7a39f642cc72ad7b629b22da5b189314f3d5_1280.jpg";
      case "pontoon":
        return "https://pixabay.com/get/gb449283ba3d3cef73df523a11e54b7bc771865c015bd394ed583407562764cdc177cf57c262cfb4b97eb020f5a5dcde1f3824c5428f3d9ae69da1e1033add851_1280.jpg";
      default:
        return "https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250";
    }
  };

  const displayImage = boat.images && boat.images.length > 0 ? boat.images[0] : getDefaultImage(boat.type);
  const rating = parseFloat(boat.rating || "0");

  return (
    <>
      <Card className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden transform hover:-translate-y-2">
        <img 
          src={displayImage}
          alt={boat.name}
          className="w-full h-48 object-cover"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.src = getDefaultImage(boat.type);
          }}
        />
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-2">
            <Badge className={getTypeColor(boat.type)}>
              {boat.type.charAt(0).toUpperCase() + boat.type.slice(1)}
            </Badge>
            <div className="flex items-center text-yellow-400">
              <Star className="h-4 w-4 fill-current" />
              <span className="ml-1 text-sm text-gray-600">
                {rating > 0 ? rating.toFixed(1) : "New"}
              </span>
            </div>
          </div>
          
          <h3 className="text-xl font-bold text-dark-teal mb-2">{boat.name}</h3>
          
          <p className="text-gray-600 text-sm mb-4 line-clamp-2">
            {boat.description}
          </p>
          
          <div className="flex items-center text-sm text-gray-500 mb-4 space-x-4">
            <span>{boat.length}ft</span>
            <span>•</span>
            <span>Up to {boat.capacity} guests</span>
            <span>•</span>
            <span>{boat.location}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <span className="text-2xl font-bold text-coral">
                ${parseFloat(boat.dailyRate).toLocaleString()}
              </span>
              <span className="text-gray-500 text-sm">/day</span>
            </div>
            <Button 
              onClick={() => setIsBookingModalOpen(true)}
              className="bg-coral text-white hover:bg-coral/90 px-6 py-2 rounded-lg font-medium transition-colors"
            >
              Book Now
            </Button>
          </div>
        </CardContent>
      </Card>

      <BookingModal
        boat={boat}
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
      />
    </>
  );
}

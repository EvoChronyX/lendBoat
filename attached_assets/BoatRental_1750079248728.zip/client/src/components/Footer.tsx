import { Link } from "wouter";
import { Anchor } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const scrollToSection = (sectionId: string) => {
    const element = document.querySelector(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-dark-teal text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-teal to-sandal rounded-lg flex items-center justify-center">
                <Anchor className="text-white text-lg" />
              </div>
              <span className="text-xl font-bold">AquaRent</span>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              Your premier destination for boat and yacht rentals. Making premium boating accessible to everyone.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors"
                aria-label="Facebook"
              >
                <i className="fab fa-facebook-f"></i>
              </a>
              <a 
                href="#" 
                className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors"
                aria-label="Instagram"
              >
                <i className="fab fa-instagram"></i>
              </a>
              <a 
                href="#" 
                className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors"
                aria-label="Twitter"
              >
                <i className="fab fa-twitter"></i>
              </a>
              <a 
                href="#" 
                className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors"
                aria-label="YouTube"
              >
                <i className="fab fa-youtube"></i>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <button 
                  onClick={() => scrollToSection('#home')}
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  Home
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('#about')}
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  About Us
                </button>
              </li>
              <li>
                <Link href="/boats">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">
                    Boat Listings
                  </span>
                </Link>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('#owner-registration')}
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  List Your Boat
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('#contact')}
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  Contact
                </button>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Services</h3>
            <ul className="space-y-3">
              <li><span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Yacht Rentals</span></li>
              <li><span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Sailboat Charters</span></li>
              <li><span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Fishing Trips</span></li>
              <li><span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Corporate Events</span></li>
              <li><span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Group Bookings</span></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Legal</h3>
            <ul className="space-y-3">
              <li><span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Privacy Policy</span></li>
              <li><span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Terms of Service</span></li>
              <li><span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Cancellation Policy</span></li>
              <li><span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Insurance</span></li>
              <li><span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Safety Guidelines</span></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-300 text-sm">
              © {currentYear} AquaRent. All rights reserved.
            </p>
            <p className="text-gray-300 text-sm mt-4 md:mt-0">
              Made with <i className="fas fa-heart text-coral"></i> for water enthusiasts
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

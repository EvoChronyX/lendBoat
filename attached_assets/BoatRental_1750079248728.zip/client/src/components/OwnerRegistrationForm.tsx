import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { apiRequest } from "@/lib/queryClient";
import { Upload } from "lucide-react";

export default function OwnerRegistrationForm() {
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    boatName: "",
    boatType: "",
    length: "",
    capacity: "",
    dailyRate: "",
    description: "",
    location: "",
    termsAccepted: false,
  });

  const registerOwnerMutation = useMutation({
    mutationFn: async (data: any) => {
      if (!isAuthenticated) {
        window.location.href = "/api/login";
        return;
      }
      await apiRequest("POST", "/api/owners/register", data);
    },
    onSuccess: () => {
      toast({
        title: "Registration Submitted",
        description: "Your owner registration has been submitted for review. You'll receive an email notification once it's processed.",
      });
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        boatName: "",
        boatType: "",
        length: "",
        capacity: "",
        dailyRate: "",
        description: "",
        location: "",
        termsAccepted: false,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Authentication Required",
          description: "Please log in to register as a boat owner.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 2000);
        return;
      }
      toast({
        title: "Registration Failed",
        description: "There was an error submitting your registration. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.termsAccepted) {
      toast({
        title: "Terms Required",
        description: "Please accept the terms and conditions to proceed.",
        variant: "destructive",
      });
      return;
    }

    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to register as a boat owner.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 2000);
      return;
    }

    // Prepare the data for submission
    const ownerData = {
      firstName: formData.firstName,
      lastName: formData.lastName,
      email: formData.email,
      phone: formData.phone,
    };

    registerOwnerMutation.mutate(ownerData);
  };

  return (
    <section id="owner-registration" className="py-20 bg-light-gray">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-dark-teal mb-4">List Your Boat</h2>
          <p className="text-xl text-gray-600">Join our network of boat owners and start earning from your vessel</p>
        </div>

        <Card className="bg-white rounded-2xl shadow-lg">
          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Owner Information */}
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">First Name *</label>
                  <Input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={(e) => handleInputChange("firstName", e.target.value)}
                    className="rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Last Name *</label>
                  <Input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={(e) => handleInputChange("lastName", e.target.value)}
                    className="rounded-xl"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email *</label>
                  <Input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    className="rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                  <Input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    className="rounded-xl"
                  />
                </div>
              </div>

              {/* Boat Information Section - For display purposes */}
              <div className="pt-6 border-t border-gray-200">
                <h3 className="text-xl font-semibold text-dark-teal mb-4">Boat Information (Optional)</h3>
                <p className="text-sm text-gray-600 mb-6">
                  You can add your boat details after your owner account is approved.
                </p>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Boat Name</label>
                    <Input
                      type="text"
                      value={formData.boatName}
                      onChange={(e) => handleInputChange("boatName", e.target.value)}
                      className="rounded-xl"
                      placeholder="e.g., Ocean Explorer"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Boat Type</label>
                    <Select value={formData.boatType} onValueChange={(value) => handleInputChange("boatType", value)}>
                      <SelectTrigger className="rounded-xl">
                        <SelectValue placeholder="Select Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="yacht">Yacht</SelectItem>
                        <SelectItem value="sailboat">Sailboat</SelectItem>
                        <SelectItem value="speedboat">Speedboat</SelectItem>
                        <SelectItem value="catamaran">Catamaran</SelectItem>
                        <SelectItem value="fishing">Fishing Boat</SelectItem>
                        <SelectItem value="pontoon">Pontoon</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Length (ft)</label>
                    <Input
                      type="number"
                      value={formData.length}
                      onChange={(e) => handleInputChange("length", e.target.value)}
                      className="rounded-xl"
                      placeholder="e.g., 32"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Capacity</label>
                    <Input
                      type="number"
                      value={formData.capacity}
                      onChange={(e) => handleInputChange("capacity", e.target.value)}
                      className="rounded-xl"
                      placeholder="e.g., 8"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Daily Rate ($)</label>
                    <Input
                      type="number"
                      value={formData.dailyRate}
                      onChange={(e) => handleInputChange("dailyRate", e.target.value)}
                      className="rounded-xl"
                      placeholder="e.g., 450"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                  <Textarea
                    rows={4}
                    value={formData.description}
                    onChange={(e) => handleInputChange("description", e.target.value)}
                    className="rounded-xl"
                    placeholder="Describe your boat's features and amenities..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Boat Images</label>
                  <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-teal transition-colors">
                    <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <p className="text-gray-600 mb-2">Drop your images here or click to browse</p>
                    <p className="text-sm text-gray-500">Support: JPG, PNG, WebP (Max: 5MB each)</p>
                    <p className="text-xs text-gray-400 mt-2">Image upload will be available after account approval</p>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Marina Location</label>
                  <Input
                    type="text"
                    value={formData.location}
                    onChange={(e) => handleInputChange("location", e.target.value)}
                    placeholder="e.g., Miami Beach Marina"
                    className="rounded-xl"
                  />
                </div>
              </div>

              {/* Terms and Submit */}
              <div className="pt-6 border-t border-gray-200">
                <div className="flex items-start mb-6 space-x-3">
                  <Checkbox
                    id="terms"
                    checked={formData.termsAccepted}
                    onCheckedChange={(checked) => handleInputChange("termsAccepted", checked as boolean)}
                    required
                  />
                  <label htmlFor="terms" className="text-sm text-gray-700 leading-relaxed">
                    I agree to the Terms of Service and Privacy Policy. I confirm that I own or have authorization to list boats on this platform.
                  </label>
                </div>

                <Button
                  type="submit"
                  disabled={registerOwnerMutation.isPending}
                  className="w-full bg-teal text-white py-4 rounded-xl font-semibold text-lg hover:bg-dark-teal transition-colors"
                >
                  {registerOwnerMutation.isPending ? "Submitting..." : "Submit for Approval"}
                </Button>

                <p className="text-sm text-gray-600 text-center mt-4">
                  Your submission will be reviewed by our team within 24-48 hours. You'll receive an email notification with the approval status.
                </p>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}

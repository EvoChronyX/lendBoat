import { Button } from "@/components/ui/button";
import { Compass } from "lucide-react";

export default function HeroSection() {
  const scrollToBoats = () => {
    const boatsSection = document.querySelector('#boats');
    if (boatsSection) {
      boatsSection.scrollIntoView({ behavior: 'smooth' });
    } else {
      // If on landing page, scroll to featured boats
      const featuredSection = document.querySelector('[data-section="featured-boats"]');
      if (featuredSection) {
        featuredSection.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <section className="bg-sandal relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              <span className="block">Sail Into Your</span>
              <span className="block">Dream Adventure</span>
            </h1>
            <p className="text-xl text-white/90 mb-8 leading-relaxed">
              Discover premium boats and yachts for unforgettable experiences on the water. From intimate sailing to luxury yacht charters.
            </p>
            <Button 
              onClick={scrollToBoats}
              className="bg-white text-sandal px-8 py-4 rounded-xl font-semibold text-lg hover:bg-gray-50 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              <Compass className="mr-2 h-5 w-5" />
              Explore More
            </Button>
          </div>
          <div className="hidden lg:block">
            <img 
              src="https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Luxury yacht on calm waters" 
              className="rounded-2xl shadow-2xl w-full h-auto"
            />
          </div>
        </div>
      </div>
      
      {/* Decorative wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg 
          viewBox="0 0 1200 120" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg" 
          className="w-full h-12 text-white"
        >
          <path 
            d="M0 120L48 110C96 100 192 80 288 70C384 60 480 60 576 65C672 70 768 80 864 85C960 90 1056 90 1152 85L1200 80V120H1152C1056 120 960 120 864 120C768 120 672 120 576 120C480 120 384 120 288 120C192 120 96 120 48 120H0Z" 
            fill="currentColor"
          />
        </svg>
      </div>
    </section>
  );
}

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";

interface AnalyticsChartProps {
  data: Array<{
    month: string;
    count: number;
    revenue: number;
  }>;
  type?: "line" | "bar";
  dataKey?: "count" | "revenue";
}

export default function AnalyticsChart({ 
  data, 
  type = "line", 
  dataKey = "count" 
}: AnalyticsChartProps) {
  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-gray-500">
        <div className="text-center">
          <div className="text-4xl mb-2">📊</div>
          <p>No data available</p>
        </div>
      </div>
    );
  }

  // Format the data for display
  const chartData = data.map(item => ({
    ...item,
    month: new Date(item.month).toLocaleDateString("en-US", { 
      month: "short", 
      year: "numeric" 
    }),
    revenue: typeof item.revenue === "string" ? parseFloat(item.revenue) : item.revenue,
  }));

  const formatYAxisTick = (value: number) => {
    if (dataKey === "revenue") {
      return `$${value.toLocaleString()}`;
    }
    return value.toString();
  };

  const formatTooltipValue = (value: number, name: string) => {
    if (name === "revenue") {
      return [`$${value.toLocaleString()}`, "Revenue"];
    }
    if (name === "count") {
      return [value, "Bookings"];
    }
    return [value, name];
  };

  if (type === "bar") {
    return (
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis 
            dataKey="month" 
            stroke="#666" 
            fontSize={12}
          />
          <YAxis 
            stroke="#666" 
            fontSize={12}
            tickFormatter={formatYAxisTick}
          />
          <Tooltip
            formatter={formatTooltipValue}
            labelStyle={{ color: "#333" }}
            contentStyle={{
              backgroundColor: "white",
              border: "1px solid #e5e7eb",
              borderRadius: "8px",
              boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
            }}
          />
          <Bar 
            dataKey={dataKey} 
            fill="hsl(var(--teal))" 
            radius={[4, 4, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
        <XAxis 
          dataKey="month" 
          stroke="#666" 
          fontSize={12}
        />
        <YAxis 
          stroke="#666" 
          fontSize={12}
          tickFormatter={formatYAxisTick}
        />
        <Tooltip
          formatter={formatTooltipValue}
          labelStyle={{ color: "#333" }}
          contentStyle={{
            backgroundColor: "white",
            border: "1px solid #e5e7eb",
            borderRadius: "8px",
            boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
          }}
        />
        <Line 
          type="monotone" 
          dataKey={dataKey} 
          stroke="hsl(var(--teal))" 
          strokeWidth={3}
          dot={{ fill: "hsl(var(--teal))", strokeWidth: 2, r: 4 }}
          activeDot={{ r: 6, stroke: "hsl(var(--teal))", strokeWidth: 2 }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

import { useUser } from "@clerk/nextjs";

export function useAuth() {
  const { user, isLoaded } = useUser();

  return {
    user,
    isLoading: !isLoaded,
    isAuthenticated: !!user,
  };
}

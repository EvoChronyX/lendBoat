# Production Deployment Guide

This guide helps you deploy your boat rental platform independently from Replit using external services.

## External Services Required

### 1. PostgreSQL Database
You need an external PostgreSQL database. Recommended providers:
- **Neon** (https://neon.tech) - Serverless PostgreSQL
- **Supabase** (https://supabase.com) - Full-stack platform with PostgreSQL
- **Railway** (https://railway.app) - Simple PostgreSQL hosting
- **AWS RDS** - Enterprise-grade PostgreSQL
- **Google Cloud SQL** - Managed PostgreSQL service

Get your `DATABASE_URL` connection string from your provider.

### 2. Authentication with Clerk
- Go to https://clerk.com and create an account
- Create a new application
- Get your API keys from the dashboard:
  - `CLERK_PUBLISHABLE_KEY` (starts with pk_)
  - `CLERK_SECRET_KEY` (starts with sk_)

### 3. Payment Processing with Stripe
- Go to https://dashboard.stripe.com/apikeys
- Get your API keys:
  - `STRIPE_SECRET_KEY` (starts with sk_)
  - `VITE_STRIPE_PUBLIC_KEY` (starts with pk_)

### 4. Email Service (Choose One)

#### Option A: SendGrid
- Sign up at https://sendgrid.com
- Get your `SENDGRID_API_KEY`

#### Option B: Gmail App Password
- Enable 2FA on your Gmail account
- Generate an app-specific password
- Use `GMAIL_USER` and `GMAIL_APP_PASSWORD`

#### Option C: Custom SMTP
- Use any SMTP provider (AWS SES, Mailgun, etc.)
- Set `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`

## Environment Variables

Create a `.env` file with these variables:

```env
# Database
DATABASE_URL=postgresql://username:password@hostname:5432/database_name

# Authentication
CLERK_PUBLISHABLE_KEY=pk_test_...
CLERK_SECRET_KEY=sk_test_...

# Payment
STRIPE_SECRET_KEY=sk_test_...
VITE_STRIPE_PUBLIC_KEY=pk_test_...

# Email (choose one method)
SENDGRID_API_KEY=SG.xxx...
FROM_EMAIL=noreply@yourdomain.com

# Security
SESSION_SECRET=your-super-secret-session-key-minimum-32-characters

# Environment
NODE_ENV=production
```

## Database Setup

1. Create your external PostgreSQL database
2. Update the `DATABASE_URL` in your environment
3. Run the schema migration:
   ```bash
   npm run db:push
   ```

## Deployment Options

### Option 1: Vercel (Recommended for Frontend + API)
1. Push your code to GitHub
2. Connect your GitHub repo to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy automatically

### Option 2: Railway
1. Connect your GitHub repo to Railway
2. Add environment variables
3. Deploy with automatic builds

### Option 3: AWS/Google Cloud
1. Build your application:
   ```bash
   npm run build
   ```
2. Deploy to your cloud provider
3. Set up environment variables
4. Configure your domain

### Option 4: Self-Hosted VPS
1. Set up a Linux server (Ubuntu/CentOS)
2. Install Node.js and PostgreSQL
3. Clone your repository
4. Install dependencies: `npm install`
5. Set up environment variables
6. Use PM2 for process management:
   ```bash
   npm install -g pm2
   pm2 start server/index.ts --name boat-rental
   ```
7. Set up Nginx as reverse proxy

## Domain and SSL

1. Purchase a domain name
2. Point DNS to your hosting provider
3. Enable SSL/TLS certificates (most hosts provide free Let's Encrypt certificates)

## Production Checklist

- [ ] External PostgreSQL database configured
- [ ] Clerk authentication working
- [ ] Stripe payments functional
- [ ] Email service operational
- [ ] All environment variables set
- [ ] Database schema migrated
- [ ] SSL certificate installed
- [ ] Domain configured
- [ ] Error monitoring set up (optional: Sentry)
- [ ] Backup strategy implemented

## Security Best Practices

1. **Never commit secrets** to version control
2. **Use environment variables** for all configuration
3. **Enable SSL/TLS** for all connections
4. **Regular database backups**
5. **Monitor error logs**
6. **Keep dependencies updated**

## Monitoring and Maintenance

1. Set up error tracking (Sentry, LogRocket)
2. Monitor database performance
3. Regular security updates
4. Database backup schedule
5. Performance monitoring

## Cost Estimates (Monthly)

- **Database**: $0-50 (depending on usage)
- **Hosting**: $0-20 (Vercel/Railway free tiers available)
- **Domain**: $10-15/year
- **Email Service**: $0-20 (SendGrid free tier: 100 emails/day)
- **Total**: ~$5-85/month

Your application is now completely independent from Replit and ready for production deployment!
import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./clerkAuth";
import { insertOwnerSchema, insertBoatSchema, insertBookingSchema, insertTestimonialSchema, insertContactSchema } from "@shared/schema";
import { z } from "zod";





if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16",
});

// Helper function to generate secret key
function generateSecretKey(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 7; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      let user = await storage.getUser(userId);
      
      // Create user in database if doesn't exist
      if (!user && req.user.email) {
        user = await storage.upsertUser({
          id: userId,
          email: req.user.email,
          firstName: req.user.firstName,
          lastName: req.user.lastName,
          profileImageUrl: req.user.profileImageUrl,
        });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Boat routes
  app.get('/api/boats', async (req, res) => {
    try {
      const { type, location, minPrice, maxPrice } = req.query;
      const filters: any = {};
      
      if (type) filters.type = type as string;
      if (location) filters.location = location as string;
      if (minPrice) filters.minPrice = Number(minPrice);
      if (maxPrice) filters.maxPrice = Number(maxPrice);
      
      const boats = Object.keys(filters).length > 0 
        ? await storage.searchBoats(filters)
        : await storage.getAllBoats();
      
      res.json(boats);
    } catch (error) {
      console.error("Error fetching boats:", error);
      res.status(500).json({ message: "Failed to fetch boats" });
    }
  });

  app.get('/api/boats/:id', async (req, res) => {
    try {
      const boat = await storage.getBoat(Number(req.params.id));
      if (!boat) {
        return res.status(404).json({ message: "Boat not found" });
      }
      res.json(boat);
    } catch (error) {
      console.error("Error fetching boat:", error);
      res.status(500).json({ message: "Failed to fetch boat" });
    }
  });

  app.post('/api/boats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const owner = await storage.getOwnerByUserId(userId);
      
      if (!owner || owner.status !== 'approved') {
        return res.status(403).json({ message: "Only approved owners can list boats" });
      }

      const boatData = insertBoatSchema.parse({
        ...req.body,
        ownerId: owner.id,
      });

      const boat = await storage.createBoat(boatData);
      res.status(201).json(boat);
    } catch (error) {
      console.error("Error creating boat:", error);
      res.status(500).json({ message: "Failed to create boat" });
    }
  });

  // Owner routes
  app.post('/api/owners/register', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Check if user already has an owner profile
      const existingOwner = await storage.getOwnerByUserId(userId);
      if (existingOwner) {
        return res.status(400).json({ message: "Owner profile already exists" });
      }

      const ownerData = insertOwnerSchema.parse({
        ...req.body,
        userId,
      });

      const owner = await storage.createOwner(ownerData);
      res.status(201).json(owner);
    } catch (error) {
      console.error("Error registering owner:", error);
      res.status(500).json({ message: "Failed to register owner" });
    }
  });

  app.get('/api/owners/me', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const owner = await storage.getOwnerByUserId(userId);
      res.json(owner);
    } catch (error) {
      console.error("Error fetching owner profile:", error);
      res.status(500).json({ message: "Failed to fetch owner profile" });
    }
  });

  // Booking routes
  app.post('/api/bookings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const secretKey = generateSecretKey();
      
      const bookingData = insertBookingSchema.parse({
        ...req.body,
        userId,
      });

      const booking = await storage.createBooking({
        ...bookingData,
        secretKey,
      });

      res.status(201).json(booking);
    } catch (error) {
      console.error("Error creating booking:", error);
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  app.get('/api/bookings/me', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookings = await storage.getUserBookings(userId);
      res.json(bookings);
    } catch (error) {
      console.error("Error fetching user bookings:", error);
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  app.get('/api/bookings/:secretKey', async (req, res) => {
    try {
      const booking = await storage.getBookingBySecretKey(req.params.secretKey);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      res.json(booking);
    } catch (error) {
      console.error("Error fetching booking:", error);
      res.status(500).json({ message: "Failed to fetch booking" });
    }
  });

  // Stripe payment routes
  app.post("/api/create-payment-intent", isAuthenticated, async (req, res) => {
    try {
      const { amount, bookingId } = req.body;
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        metadata: {
          bookingId: bookingId?.toString() || '',
        },
      });

      if (bookingId) {
        await storage.updateBookingPayment(
          bookingId,
          paymentIntent.id,
          'pending'
        );
      }

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Testimonial routes
  app.get('/api/testimonials', async (req, res) => {
    try {
      const testimonials = await storage.getApprovedTestimonials();
      res.json(testimonials);
    } catch (error) {
      console.error("Error fetching testimonials:", error);
      res.status(500).json({ message: "Failed to fetch testimonials" });
    }
  });

  app.post('/api/testimonials', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const testimonialData = insertTestimonialSchema.parse({
        ...req.body,
        userId,
      });

      const testimonial = await storage.createTestimonial(testimonialData);
      res.status(201).json(testimonial);
    } catch (error) {
      console.error("Error creating testimonial:", error);
      res.status(500).json({ message: "Failed to create testimonial" });
    }
  });

  // Contact routes
  app.post('/api/contact', async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(contactData);
      res.status(201).json(contact);
    } catch (error) {
      console.error("Error creating contact:", error);
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  // Admin routes
  app.get('/api/admin/owners', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const owners = await storage.getAllOwners();
      res.json(owners);
    } catch (error) {
      console.error("Error fetching owners:", error);
      res.status(500).json({ message: "Failed to fetch owners" });
    }
  });

  app.put('/api/admin/owners/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { status, rejectionReason } = req.body;
      const owner = await storage.updateOwnerStatus(
        Number(req.params.id),
        status,
        rejectionReason
      );

      res.json(owner);
    } catch (error) {
      console.error("Error updating owner status:", error);
      res.status(500).json({ message: "Failed to update owner status" });
    }
  });

  app.get('/api/admin/analytics', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getBookingStats();
      const popularBoats = await storage.getPopularBoats();

      res.json({
        bookingStats: stats,
        popularBoats,
      });
    } catch (error) {
      console.error("Error fetching analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  app.get('/api/admin/testimonials', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const testimonials = await storage.getAllTestimonials();
      res.json(testimonials);
    } catch (error) {
      console.error("Error fetching testimonials:", error);
      res.status(500).json({ message: "Failed to fetch testimonials" });
    }
  });

  app.put('/api/admin/testimonials/:id/approve', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { isApproved } = req.body;
      const testimonial = await storage.updateTestimonialStatus(
        Number(req.params.id),
        isApproved
      );

      res.json(testimonial);
    } catch (error) {
      console.error("Error updating testimonial:", error);
      res.status(500).json({ message: "Failed to update testimonial" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

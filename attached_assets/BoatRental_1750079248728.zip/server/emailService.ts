import nodemailer from 'nodemailer';

export interface EmailConfig {
  host: string;
  port: number;
  secure: boolean;
  auth: {
    user: string;
    pass: string;
  };
}

export class EmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    // Configure based on environment variables
    if (process.env.SMTP_HOST) {
      // Custom SMTP configuration
      this.transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT || '587'),
        secure: process.env.SMTP_SECURE === 'true',
        auth: {
          user: process.env.SMTP_USER!,
          pass: process.env.SMTP_PASS!,
        },
      });
    } else if (process.env.SENDGRID_API_KEY) {
      // SendGrid configuration
      this.transporter = nodemailer.createTransport({
        service: 'SendGrid',
        auth: {
          user: 'apikey',
          pass: process.env.SENDGRID_API_KEY,
        },
      });
    } else if (process.env.GMAIL_USER && process.env.GMAIL_APP_PASSWORD) {
      // Gmail configuration
      this.transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: process.env.GMAIL_USER,
          pass: process.env.GMAIL_APP_PASSWORD,
        },
      });
    } else {
      throw new Error('No email service configured. Please set SMTP, SendGrid, or Gmail credentials.');
    }
  }

  async sendEmail(options: {
    to: string;
    subject: string;
    text?: string;
    html?: string;
    from?: string;
  }) {
    try {
      const mailOptions = {
        from: options.from || process.env.FROM_EMAIL || 'noreply@boatrental.com',
        to: options.to,
        subject: options.subject,
        text: options.text,
        html: options.html,
      };

      const result = await this.transporter.sendMail(mailOptions);
      console.log('Email sent successfully:', result.messageId);
      return result;
    } catch (error) {
      console.error('Error sending email:', error);
      throw error;
    }
  }

  async sendBookingConfirmation(userEmail: string, bookingDetails: any) {
    const html = `
      <h2>Booking Confirmation</h2>
      <p>Dear ${bookingDetails.userName},</p>
      <p>Your boat rental has been confirmed!</p>
      <div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">
        <h3>Booking Details</h3>
        <p><strong>Boat:</strong> ${bookingDetails.boatName}</p>
        <p><strong>Start Date:</strong> ${bookingDetails.startDate}</p>
        <p><strong>End Date:</strong> ${bookingDetails.endDate}</p>
        <p><strong>Total Amount:</strong> $${bookingDetails.totalAmount}</p>
        <p><strong>Booking Reference:</strong> ${bookingDetails.secretKey}</p>
      </div>
      <p>Thank you for choosing our boat rental service!</p>
    `;

    return this.sendEmail({
      to: userEmail,
      subject: 'Booking Confirmation - Boat Rental',
      html,
    });
  }

  async sendOwnerApprovalNotification(ownerEmail: string, ownerName: string, approved: boolean) {
    const status = approved ? 'approved' : 'rejected';
    const html = `
      <h2>Owner Application ${approved ? 'Approved' : 'Rejected'}</h2>
      <p>Dear ${ownerName},</p>
      <p>Your application to become a boat owner has been ${status}.</p>
      ${approved 
        ? '<p>You can now start listing your boats on our platform!</p>' 
        : '<p>Please contact support if you have any questions.</p>'
      }
      <p>Best regards,<br>Boat Rental Team</p>
    `;

    return this.sendEmail({
      to: ownerEmail,
      subject: `Owner Application ${approved ? 'Approved' : 'Rejected'}`,
      html,
    });
  }
}

export const emailService = new EmailService();
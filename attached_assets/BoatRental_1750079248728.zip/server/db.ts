import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from "@shared/schema";

process.env.DATABASE_URL="postgresql://neondb_owner:npg_sR5aU8udHiTb@ep-tight-frog-a6tweepq.us-west-2.aws.neon.tech/neondb?sslmode=require";

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Please provide your external PostgreSQL database connection string.",
  );
}

// Create connection to external PostgreSQL database
const client = postgres(process.env.DATABASE_URL, {
  ssl: 'require',
  max: 10,
});

export const db = drizzle(client, { schema });
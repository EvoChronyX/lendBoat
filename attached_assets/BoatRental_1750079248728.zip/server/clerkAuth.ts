import { ClerkExpressWithAuth, clerkClient } from '@clerk/clerk-sdk-node';
import type { Express, RequestHandler } from "express";




if (!process.env.CLERK_SECRET_KEY) {
  throw new Error("CLERK_SECRET_KEY environment variable must be set");
}

// Initialize Clerk client
export const clerk = clerkClient;

// Clerk middleware for authentication
export const requireAuth = ClerkExpressWithAuth();

// Custom middleware to check authentication
export const isAuthenticated: RequestHandler = (req: any, res, next) => {
  if (!req.auth?.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
};

// Middleware to sync Clerk user with our database
export const syncUserWithDatabase: RequestHandler = async (req: any, res, next) => {
  if (req.auth?.userId) {
    try {
      const clerkUser = await clerk.users.getUser(req.auth.userId);
      req.user = {
        id: clerkUser.id,
        email: clerkUser.emailAddresses[0]?.emailAddress,
        firstName: clerkUser.firstName,
        lastName: clerkUser.lastName,
        profileImageUrl: clerkUser.imageUrl,
      };
    } catch (error) {
      console.error("Error getting user from Clerk:", error);
      req.user = { id: req.auth.userId };
    }
  }
  next();
};

export async function setupAuth(app: Express) {
  // Apply Clerk middleware to all API routes
  app.use('/api', requireAuth);
  app.use('/api', syncUserWithDatabase);
}
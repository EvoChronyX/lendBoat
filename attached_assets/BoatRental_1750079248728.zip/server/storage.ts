import {
  users,
  owners,
  boats,
  bookings,
  testimonials,
  contacts,
  type User,
  type UpsertUser,
  type InsertOwner,
  type Owner,
  type InsertBoat,
  type Boat,
  type InsertBooking,
  type Booking,
  type InsertTestimonial,
  type Testimonial,
  type InsertContact,
  type Contact,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, count, sql, avg } from "drizzle-orm";

export interface IStorage {
  // User operations - required for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserStripeInfo(userId: string, stripeData: { customerId?: string; subscriptionId?: string }): Promise<User>;

  // Owner operations
  createOwner(owner: InsertOwner): Promise<Owner>;
  getOwner(id: number): Promise<Owner | undefined>;
  getOwnerByUserId(userId: string): Promise<Owner | undefined>;
  getAllOwners(): Promise<Owner[]>;
  updateOwnerStatus(id: number, status: "approved" | "rejected", rejectionReason?: string): Promise<Owner>;

  // Boat operations
  createBoat(boat: InsertBoat): Promise<Boat>;
  getBoat(id: number): Promise<Boat | undefined>;
  getAllBoats(): Promise<Boat[]>;
  getBoatsByOwner(ownerId: number): Promise<Boat[]>;
  searchBoats(filters: { type?: string; location?: string; minPrice?: number; maxPrice?: number }): Promise<Boat[]>;
  updateBoat(id: number, updates: Partial<InsertBoat>): Promise<Boat>;
  deleteBoat(id: number): Promise<void>;

  // Booking operations
  createBooking(booking: InsertBooking & { secretKey: string }): Promise<Booking>;
  getBooking(id: number): Promise<Booking | undefined>;
  getBookingBySecretKey(secretKey: string): Promise<Booking | undefined>;
  getUserBookings(userId: string): Promise<Booking[]>;
  getOwnerBookings(ownerId: number): Promise<Booking[]>;
  updateBookingStatus(id: number, status: string, paymentStatus?: string): Promise<Booking>;
  updateBookingPayment(id: number, paymentIntentId: string, paymentStatus: string): Promise<Booking>;

  // Testimonial operations
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
  getApprovedTestimonials(): Promise<Testimonial[]>;
  getAllTestimonials(): Promise<Testimonial[]>;
  updateTestimonialStatus(id: number, isApproved: boolean): Promise<Testimonial>;

  // Contact operations
  createContact(contact: InsertContact): Promise<Contact>;
  getAllContacts(): Promise<Contact[]>;

  // Analytics
  getBookingStats(): Promise<{ totalBookings: number; totalRevenue: number; monthlyBookings: any[] }>;
  getPopularBoats(): Promise<{ boat: Boat; bookingCount: number }[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: string, stripeData: { customerId?: string; subscriptionId?: string }): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        stripeCustomerId: stripeData.customerId,
        stripeSubscriptionId: stripeData.subscriptionId,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Owner operations
  async createOwner(owner: InsertOwner): Promise<Owner> {
    const [newOwner] = await db.insert(owners).values(owner).returning();
    return newOwner;
  }

  async getOwner(id: number): Promise<Owner | undefined> {
    const [owner] = await db.select().from(owners).where(eq(owners.id, id));
    return owner;
  }

  async getOwnerByUserId(userId: string): Promise<Owner | undefined> {
    const [owner] = await db.select().from(owners).where(eq(owners.userId, userId));
    return owner;
  }

  async getAllOwners(): Promise<Owner[]> {
    return await db.select().from(owners).orderBy(desc(owners.createdAt));
  }

  async updateOwnerStatus(id: number, status: "approved" | "rejected", rejectionReason?: string): Promise<Owner> {
    const [owner] = await db
      .update(owners)
      .set({
        status,
        rejectionReason,
        updatedAt: new Date(),
      })
      .where(eq(owners.id, id))
      .returning();
    return owner;
  }

  // Boat operations
  async createBoat(boat: InsertBoat): Promise<Boat> {
    const [newBoat] = await db.insert(boats).values(boat).returning();
    return newBoat;
  }

  async getBoat(id: number): Promise<Boat | undefined> {
    const [boat] = await db.select().from(boats).where(eq(boats.id, id));
    return boat;
  }

  async getAllBoats(): Promise<Boat[]> {
    return await db.select().from(boats).where(eq(boats.isActive, true)).orderBy(desc(boats.createdAt));
  }

  async getBoatsByOwner(ownerId: number): Promise<Boat[]> {
    return await db.select().from(boats).where(eq(boats.ownerId, ownerId)).orderBy(desc(boats.createdAt));
  }

  async searchBoats(filters: { type?: string; location?: string; minPrice?: number; maxPrice?: number }): Promise<Boat[]> {
    let query = db.select().from(boats).where(eq(boats.isActive, true));
    
    const conditions = [eq(boats.isActive, true)];
    
    if (filters.type && filters.type !== "All Types") {
      conditions.push(eq(boats.type, filters.type.toLowerCase()));
    }
    
    if (filters.location) {
      conditions.push(sql`${boats.location} ILIKE ${`%${filters.location}%`}`);
    }
    
    if (filters.minPrice) {
      conditions.push(gte(boats.dailyRate, filters.minPrice.toString()));
    }
    
    if (filters.maxPrice) {
      conditions.push(lte(boats.dailyRate, filters.maxPrice.toString()));
    }
    
    return await db.select().from(boats).where(and(...conditions)).orderBy(desc(boats.createdAt));
  }

  async updateBoat(id: number, updates: Partial<InsertBoat>): Promise<Boat> {
    const [boat] = await db
      .update(boats)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(boats.id, id))
      .returning();
    return boat;
  }

  async deleteBoat(id: number): Promise<void> {
    await db.update(boats).set({ isActive: false }).where(eq(boats.id, id));
  }

  // Booking operations
  async createBooking(booking: InsertBooking & { secretKey: string }): Promise<Booking> {
    const [newBooking] = await db.insert(bookings).values(booking).returning();
    return newBooking;
  }

  async getBooking(id: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking;
  }

  async getBookingBySecretKey(secretKey: string): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.secretKey, secretKey));
    return booking;
  }

  async getUserBookings(userId: string): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.userId, userId)).orderBy(desc(bookings.createdAt));
  }

  async getOwnerBookings(ownerId: number): Promise<Booking[]> {
    return await db
      .select()
      .from(bookings)
      .innerJoin(boats, eq(bookings.boatId, boats.id))
      .where(eq(boats.ownerId, ownerId))
      .orderBy(desc(bookings.createdAt));
  }

  async updateBookingStatus(id: number, status: string, paymentStatus?: string): Promise<Booking> {
    const updates: any = { status, updatedAt: new Date() };
    if (paymentStatus) {
      updates.paymentStatus = paymentStatus;
    }
    
    const [booking] = await db
      .update(bookings)
      .set(updates)
      .where(eq(bookings.id, id))
      .returning();
    return booking;
  }

  async updateBookingPayment(id: number, paymentIntentId: string, paymentStatus: string): Promise<Booking> {
    const [booking] = await db
      .update(bookings)
      .set({
        stripePaymentIntentId: paymentIntentId,
        paymentStatus,
        updatedAt: new Date(),
      })
      .where(eq(bookings.id, id))
      .returning();
    return booking;
  }

  // Testimonial operations
  async createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial> {
    const [newTestimonial] = await db.insert(testimonials).values(testimonial).returning();
    return newTestimonial;
  }

  async getApprovedTestimonials(): Promise<Testimonial[]> {
    return await db
      .select()
      .from(testimonials)
      .where(eq(testimonials.isApproved, true))
      .orderBy(desc(testimonials.createdAt));
  }

  async getAllTestimonials(): Promise<Testimonial[]> {
    return await db.select().from(testimonials).orderBy(desc(testimonials.createdAt));
  }

  async updateTestimonialStatus(id: number, isApproved: boolean): Promise<Testimonial> {
    const [testimonial] = await db
      .update(testimonials)
      .set({ isApproved })
      .where(eq(testimonials.id, id))
      .returning();
    return testimonial;
  }

  // Contact operations
  async createContact(contact: InsertContact): Promise<Contact> {
    const [newContact] = await db.insert(contacts).values(contact).returning();
    return newContact;
  }

  async getAllContacts(): Promise<Contact[]> {
    return await db.select().from(contacts).orderBy(desc(contacts.createdAt));
  }

  // Analytics
  async getBookingStats(): Promise<{ totalBookings: number; totalRevenue: number; monthlyBookings: any[] }> {
    const [totalStats] = await db
      .select({
        totalBookings: count(),
        totalRevenue: sql<number>`SUM(${bookings.totalAmount})`,
      })
      .from(bookings)
      .where(eq(bookings.status, "confirmed"));

    const monthlyBookings = await db
      .select({
        month: sql<string>`DATE_TRUNC('month', ${bookings.createdAt})`,
        count: count(),
        revenue: sql<number>`SUM(${bookings.totalAmount})`,
      })
      .from(bookings)
      .where(eq(bookings.status, "confirmed"))
      .groupBy(sql`DATE_TRUNC('month', ${bookings.createdAt})`)
      .orderBy(sql`DATE_TRUNC('month', ${bookings.createdAt})`);

    return {
      totalBookings: totalStats?.totalBookings || 0,
      totalRevenue: totalStats?.totalRevenue || 0,
      monthlyBookings: monthlyBookings || [],
    };
  }

  async getPopularBoats(): Promise<{ boat: Boat; bookingCount: number }[]> {
    const popularBoats = await db
      .select({
        boat: boats,
        bookingCount: count(bookings.id),
      })
      .from(boats)
      .leftJoin(bookings, eq(boats.id, bookings.boatId))
      .groupBy(boats.id)
      .orderBy(desc(count(bookings.id)))
      .limit(10);

    return popularBoats.map(item => ({
      boat: item.boat,
      bookingCount: item.bookingCount,
    }));
  }
}

export const storage = new DatabaseStorage();
